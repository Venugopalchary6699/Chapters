from indian_chef import indiancheff

mychef = indiancheff()

mychef.cheff1()