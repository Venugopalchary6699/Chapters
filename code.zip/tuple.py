coordinate = (2, 5)
#coordinates[1] = 10 ( it will show the error)


# we can create the lists of tuples

coordinates = [(2, 5), (6, 7),(80, 34)]
print(coordinates)