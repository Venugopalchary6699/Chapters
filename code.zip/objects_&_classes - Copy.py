from student_for_object import student

student1 = student("leo", "prigrammer", 9.8, False)

print(student1)
print(student1.name)
print(student1.gpa)
print(student1.is_on_probation)