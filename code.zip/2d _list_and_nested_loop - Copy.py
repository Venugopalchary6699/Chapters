number_grid = [
    [1,2, 3, 5, 9],
    [22, 33, 55, 66],
    [24, 25, 65, 78],
    [0]
]

print(number_grid[0][0])
print(number_grid[2][2])

for row in number_grid:
    for row in row:
        print(row)
