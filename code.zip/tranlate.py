Giraffe Language
vowels -> g
------------
dog -> dgg
cat -.