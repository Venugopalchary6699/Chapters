class chef:
    def cheff1(self):
        print("he make one")
    def cheff2(self):
        print("He make two")
    def chef3(self):
        print("He make three")
