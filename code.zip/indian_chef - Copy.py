from  import chef

class indiancheff(chef):
    def extra_item(self):
        print("some spacials")
