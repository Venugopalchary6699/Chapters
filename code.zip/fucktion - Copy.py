"""

"""

def say_hi():
    print("Hello user")
print("top")

say_hi()
print("bottom")
say_hi

def sayhi(name):
    print("Hello " + name)

sayhi("king")

def sayhai(name, age):
    print("Hello " + name + "you are " + str(age))

sayhai("venugopal", 25)
sayhai("gopal chary", 25)