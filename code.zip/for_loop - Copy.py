for letter in "giraffe acadamy":
    print(letter)


friends = ["jim", "karen", "kevin"]
for friend in friends:
    print(friend)

for index in range(10):
    print(index)


for indexx in range(5, 10):
    print(indexx)

for index in range(len(friends)):
    print(index)

for index in range(5):
    if index == 0:
        print("first iteration")
    else:
        print("not first")
